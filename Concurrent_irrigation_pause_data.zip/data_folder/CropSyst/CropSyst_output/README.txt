
For both the simulated areas (Washington (test case) and Fifteenmile Creek (evaluation case)), the folder structures for irrigation shutoff scenarios are similar to the optimal (full irrigation) folder. Just to keep folder structures simple, I didn't put inside watersheds information on the shutoff scenarios except for the collated seasonal results in the "result.dat" and the shutoff timeframe mentioned in the "deficit.CS_control" file. 
Inside the optimal folder, we have simulated watersheds: Methow, Okanogan, and WallaWalla, in case Fifteenmile Creek it’s Fifteenmile. Inside these watersheds, we have simulated crops for each, and inside of each crop, it has simulated grid information. Other files like:
1.	“CPF.management” explain management information.
2.	“season.UED.TDF” has required column information exported in the annual output in the result.dat file using collator. 
3.	“irrigation.TDF” has required column information to export daily irrigation column in the daily file. 
