There is a GitHub limitation when uploading larger file than 25 MB, and uploading all folder structure require huge size. Even a sample folder structure require more than 100 MB. Therefore, for each shutoff timeframe for Washington watersheds and Fifteenmile Creek, we have provided a simulated seasonal data frame file named 'result.dat' 
1. result.dat data frame has column names like "YYYY-MM-DD(DOY)", "planting_date", "harvest_date", "yield", "used_biomass", "irrig", "precip","region", "crop", "site"
NB: watershed has defined as region in the data  frame, and grid number has defined as site

If you want to look at the folder structure or want to reproduce the simulation. Please reach out to the authors: mdredwanahmad.khan@wsu.edu or kirtir@wsu.edu